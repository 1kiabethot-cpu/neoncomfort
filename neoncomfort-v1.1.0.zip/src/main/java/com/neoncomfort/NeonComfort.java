package com.neoncomfort;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class NeonComfort implements ClientModInitializer {
    private static final String CATEGORY = "category.neoncomfort";

    private static KeyBinding menuKey;
    private static KeyBinding zoomKey;

    private boolean zooming = false;
    private int savedFov = 70;
    private boolean fullbrightWasOn = false;

    // Hit Sound: 0 = OFF, далее по порядку из Modules.HIT_SOUND
    private static final String[] HIT_IDS = {
            null, "entity.experience_orb.pickup", "block.note_block.bell",
            "block.note_block.pling", "entity.arrow.hit_player", "entity.player.levelup" };
    private static final float[] HIT_PITCH = { 1f, 1.0f, 1.2f, 1.4f, 1.0f, 1.2f };
    private static final float[] HIT_VOL   = { 1f, 0.8f, 1.0f, 1.0f, 1.0f, 0.5f };

    @Override
    public void onInitializeClient() {
        Config.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.neoncomfort.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.neoncomfort.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));

        // Звук при ударе по живому существу (только на твоём клиенте)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient() && entity instanceof LivingEntity) playHitSound();
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // Кнопка в меню паузы — удобно на телефоне, где нет RShift
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("NeonComfort"),
                                        b -> client.setScreen(new MenuScreen()))
                                .dimensions(6, 6, 100, 20).build());
            }
        });
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
        }

        handleZoom(mc);
        handleFullbright(p);
        handleAutoSprint(mc, p);
        handleWeather(mc);
        handleTrail(mc, p);
        handleNoHurtCam(p);
    }

    private void playHitSound() {
        int i = Modules.HIT_SOUND.index;
        if (i <= 0 || i >= HIT_IDS.length) return;
        SoundEvent ev = SoundEvent.of(Identifier.ofVanilla(HIT_IDS[i]));
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(ev, HIT_PITCH[i], HIT_VOL[i]));
    }

    /** No Hurt Cam: сбрасываем таймер урона, камера не дёргается. */
    private void handleNoHurtCam(ClientPlayerEntity p) {
        if (Modules.NO_HURT_CAM.enabled) p.hurtTime = 0;
    }

    /** Цветной хвост у ног: виден и от первого лица (если глянуть вниз/назад), и в F5. */
    private void handleTrail(MinecraftClient mc, ClientPlayerEntity p) {
        int mode = Modules.TRAIL.index;
        if (mode == 0 || mc.world == null) return;
        double dx = p.getX() - p.prevX, dy = p.getY() - p.prevY, dz = p.getZ() - p.prevZ;
        double sp = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (sp < 0.03) return;

        boolean rainbow = (mode == Theme.colorCount() + 1);
        int n = 5;
        for (int i = 0; i < n; i++) {
            double t = i / (double) n;
            int rgb = rainbow ? Theme.rainbowRgb(i * 120L) : Theme.colorRgb(mode - 1);
            DustParticleEffect fx = new DustParticleEffect(rgb, 1.4f);
            double x = p.prevX + dx * t + (Math.random() - 0.5) * 0.5;
            double y = p.prevY + dy * t + 0.1 + Math.random() * 0.5;
            double z = p.prevZ + dz * t + (Math.random() - 0.5) * 0.5;
            mc.world.addParticle(fx, x, y, z, 0, 0, 0);
        }
    }

    /** Погода только на клиенте: видишь только ты, сервер не меняется. */
    private void handleWeather(MinecraftClient mc) {
        ClientWorld w = mc.world;
        int mode = Modules.WEATHER.index;
        if (w == null || mode == 0) return;
        // 1 Clear, 2 Rain, 3 Thunder, 4 Twilight (ясно + вечерний оттенок в Hud)
        w.setRainGradient(mode == 2 || mode == 3 ? 1f : 0f);
        w.setThunderGradient(mode == 3 ? 1f : 0f);
    }

    private void handleZoom(MinecraftClient mc) {
        boolean want = Modules.ZOOM.enabled && zoomKey.isPressed() && mc.currentScreen == null;
        if (want && !zooming) {
            savedFov = mc.options.getFov().getValue();
            mc.options.getFov().setValue(30);
            zooming = true;
        } else if (!want && zooming) {
            mc.options.getFov().setValue(savedFov);
            zooming = false;
        }
    }

    private void handleFullbright(ClientPlayerEntity p) {
        if (Modules.FULLBRIGHT.enabled) {
            p.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            fullbrightWasOn = true;
        } else if (fullbrightWasOn) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fullbrightWasOn = false;
        }
    }

    private void handleAutoSprint(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Modules.AUTOSPRINT.enabled) return;
        if (mc.options.forwardKey.isPressed()
                && !p.isSneaking()
                && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
